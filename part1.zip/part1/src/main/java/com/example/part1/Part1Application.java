package com.example.part1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Part1Application {

	public static void main(String[] args) {
		SpringApplication.run(Part1Application.class, args);
	}

}
