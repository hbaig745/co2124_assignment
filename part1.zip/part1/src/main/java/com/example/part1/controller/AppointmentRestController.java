package com.example.part1.controller;

import com.example.part1.domain.Appointment;
import com.example.part1.domain.Doctor;
import com.example.part1.domain.MedicalRecord;
import com.example.part1.domain.Patient;
import com.example.part1.repo.AppointmentRepo;
import com.example.part1.repo.DoctorRepo;
import com.example.part1.repo.PatientRepo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/appointments")
public class AppointmentRestController {
    private final AppointmentRepo appointmentRepository;
    private final DoctorRepo doctorRepository;
    private final PatientRepo patientRepository;

    public AppointmentRestController(AppointmentRepo appointmentRepository,
                                     PatientRepo patientRepository,
                                     DoctorRepo doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    @GetMapping
    public ResponseEntity<?> getAllAppointments() {
        List<Appointment> appointments = appointmentRepository.findAll();
        if (appointments.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No appointments found.");
        }
        return ResponseEntity.ok(appointmentRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable Long id) {
        return appointmentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createAppointment(@RequestBody Appointment appointment) {
        Long patientId = appointment.getPatient() != null ? appointment.getPatient().getId() : null;
        Long doctorId = appointment.getDoctor() != null ? appointment.getDoctor().getId() : null;

        if (patientId == null || doctorId == null) {
            return ResponseEntity.badRequest().body("Patient and Doctor IDs must be provided");
        }

        Optional<Patient> patient = patientRepository.findById(patientId);
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);

        if (patient.isEmpty() || doctor.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Patient or Doctor not found");
        }

        appointment.setPatient(patient.get());
        appointment.setDoctor(doctor.get());

        Appointment saved = appointmentRepository.save(appointment);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Object> updateAppointment(@PathVariable Long id, @RequestBody Appointment appointmentDetails) {
        Optional<Appointment> appointmentOptional = appointmentRepository.findById(id);

        if (appointmentOptional.isPresent()) {
            Appointment appointment = appointmentOptional.get();
            appointment.setAppointmentDate(appointmentDetails.getAppointmentDate());
            appointment.setStatus(appointmentDetails.getStatus());
            appointment.setNotes(appointmentDetails.getNotes());
            appointment.setPatient(appointmentDetails.getPatient());
            appointment.setDoctor(appointmentDetails.getDoctor());

            Appointment updatedAppointment = appointmentRepository.save(appointment);
            return ResponseEntity.ok(updatedAppointment);
        } else {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Appointment with ID " + id + " not found");
            errorResponse.put("message", "Cannot update non-existent appointment");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable Long id) {
        return appointmentRepository.findById(id)
                .map(appointment -> {
                    appointmentRepository.delete(appointment);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/medical-record")
    public ResponseEntity<?> getAppointmentMedicalRecord(@PathVariable Long id) {
        return appointmentRepository.findById(id)
                .map(appointment -> {
                    MedicalRecord medicalRecord = appointment.getMedicalRecord();
                    if (medicalRecord != null) {
                        return ResponseEntity.ok(medicalRecord);
                    } else {
                        return ResponseEntity.notFound().build();
                    }
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
