package com.example.part1.controller;

import com.example.part1.domain.Appointment;
import com.example.part1.domain.Doctor;
import com.example.part1.domain.MedicalRecord;
import com.example.part1.domain.Patient;
import com.example.part1.repo.PatientRepo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/patients")
public class PatientRestController {
    private final PatientRepo patientRepository;


    public PatientRestController(PatientRepo patientRepository) {
        this.patientRepository = patientRepository;

    }

    @GetMapping
    public ResponseEntity<?> getAllPatients() {
        List<Patient> patients = patientRepository.findAll();
        if (patients.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No patients found.");
        }
        return ResponseEntity.ok(patients);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getPatientById(@PathVariable Long id) {
        return patientRepository.findById(id)
                .map(patient -> ResponseEntity.ok().body((Object)patient))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("error", "Patient with ID " + id + " not found")));
    }

    @PostMapping
    public ResponseEntity<Object> createPatient(@RequestBody Patient patient) {
        // Check if ID is provided and already exists
        if (patient.getId() != null && patientRepository.existsById(patient.getId())) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Patient with ID " + patient.getId() + " already exists");
            errorResponse.put("message", "Use PUT request to /patients/" + patient.getId() + " to update existing patient");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }

        // For new doctor creation, ensure ID is null to let the database generate it
        patient.setId(null);
        Patient savedPatient = patientRepository.save(patient);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPatient);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updatePatient(@PathVariable Long id, @RequestBody Patient patientDetails) {
        // Check if patient exists
        Optional<Patient> patientOptional = patientRepository.findById(id);

        if (!patientOptional.isPresent()) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Patient with ID " + id + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }

        // Update patient fields
        Patient patient = patientOptional.get();
        patient.setName(patientDetails.getName());
        patient.setEmail(patientDetails.getEmail());
        patient.setPhoneNumber(patientDetails.getPhoneNumber());
        patient.setAddress(patientDetails.getAddress());

        // Save and return updated patient
        Patient updatedPatient = patientRepository.save(patient);
        return ResponseEntity.ok(updatedPatient);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deletePatient(@PathVariable Long id) {
        Optional<Patient> patientOptional = patientRepository.findById(id);

        if (patientOptional.isPresent()) {
            patientRepository.delete(patientOptional.get());
            return ResponseEntity.noContent().build();
        } else {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Patient with ID " + id + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    @GetMapping("/{id}/appointments")
    public ResponseEntity<Object> getPatientAppointments(@PathVariable Long id) {
        Optional<Patient> patientOptional = patientRepository.findById(id);

        if (patientOptional.isPresent()) {
            return ResponseEntity.ok(patientOptional.get().getAppointments());
        } else {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Patient with ID " + id + " not found");
            errorResponse.put("message", "Cannot retrieve appointments for non-existent patient");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

    @GetMapping("/{id}/medical-records")
    public ResponseEntity<Object> getPatientMedicalRecords(@PathVariable Long id) {
        Optional<Patient> patientOptional = patientRepository.findById(id);

        if (patientOptional.isPresent()) {
            List<MedicalRecord> records = patientOptional.get().getAppointments().stream()
                    .map(Appointment::getMedicalRecord)
                    .filter(record -> record != null)
                    .collect(Collectors.toList());
            return ResponseEntity.ok(records);
        } else {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Patient with ID " + id + " not found");
            errorResponse.put("message", "Cannot retrieve medical records for non-existent patient");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }
}