package com.example.part2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.example.part2.adapter.CourseAdapter;
import com.example.part2.adapter.CourseViewHolder;
import com.example.part2.data.dao.CourseDao;
import com.example.part2.data.database.AppDatabase;
import com.example.part2.data.model.Course;
import com.example.part2.ui.AddStudentActivity;
import com.example.part2.ui.CourseDetailsActivity;
import com.example.part2.ui.CreateCourseActivity;
import com.example.part2.viewmodel.AppViewModel;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.part2.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    CourseAdapter courseAdapter;
    AppViewModel appViewModel;

    @SuppressLint({"MissingInflatedId", "WrongThread"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        appViewModel = new ViewModelProvider(this).get(AppViewModel.class);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewCourses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        courseAdapter = new CourseAdapter(new CourseAdapter.CourseDiff(),
                new CourseAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Course course = courseAdapter.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, CourseDetailsActivity.class);
                intent.putExtra("course_id", course.getCourseId());
                startActivity(intent);
            }


        },  new CourseAdapter.OnItemLongClickListener() {
            @Override
            public void onItemLongClick(int position) {
                Course course = courseAdapter.getItemAtPosition(position);
                appViewModel.deleteCourse(course.getCourseId());
            }
        });
        recyclerView.setAdapter(courseAdapter);


        appViewModel.getAllCourses().observe(this, courses -> {
            courseAdapter.submitList(courses);
        });
    }

    public void navigateToCreateCourseActivity(View view) {
        Intent intent = new Intent(this, CreateCourseActivity.class);
        startActivity(intent);
    }
    }
