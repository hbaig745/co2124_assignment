package com.example.part2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.example.part2.adapter.CourseAdapter;
import com.example.part2.adapter.CourseViewHolder;
import com.example.part2.data.dao.CourseDao;
import com.example.part2.data.model.Course;
import com.example.part2.ui.CourseDetailsActivity;
import com.example.part2.ui.CreateCourseActivity;
import com.example.part2.viewmodel.AppViewModel;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewCourses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        CourseAdapter courseAdapter = new CourseAdapter(new CourseAdapter.CourseDiff());
        recyclerView.setAdapter(courseAdapter);

        AppViewModel appViewModel = new ViewModelProvider(this).get(AppViewModel.class);


        appViewModel.getAllCourses().observe(this, courses -> {
            courseAdapter.submitList(courses);
        });
        }

    public void navigateToCreateCourseActivity(View view) {
        Intent intent = new Intent(this, CreateCourseActivity.class);
        startActivity(intent);
    }


    public void onCourseClicked(Course course) {
        Intent intent = new Intent(this, CourseDetailsActivity.class);
        intent.putExtra("course_id", course.getCourseId());
        startActivity(intent);
    }


    }
