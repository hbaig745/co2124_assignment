package com.example.part2.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.R;
import com.example.part2.data.model.Course;

public class CourseViewHolder extends RecyclerView.ViewHolder {
    private final TextView courseCode;
    private final TextView courseName;
    private final TextView lecturerName;

    private CourseViewHolder(View itemView) {
        super(itemView);
        courseCode = itemView.findViewById(R.id.textCourseCode);
        courseName = itemView.findViewById(R.id.textCourseName);
        lecturerName = itemView.findViewById(R.id.textLecturerName);
    }

    public void bind(Course course) {
        courseCode.setText(course.getCourseCode());
        courseName.setText(course.getCourseName());
        lecturerName.setText(course.getLecturerName());
    }

    public void bind(OnItemClickListener listener, int position) {
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, position);
            }
        });

        itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                listener.onLongItemClick(v, position);
                return true;
            }
        });
    }

    static CourseViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_course, parent, false);
        return new CourseViewHolder(view);
}}


