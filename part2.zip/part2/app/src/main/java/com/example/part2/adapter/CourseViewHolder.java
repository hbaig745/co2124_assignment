package com.example.part2.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.R;
import com.example.part2.data.model.Course;

public class CourseViewHolder extends RecyclerView.ViewHolder {
    private final TextView courseCode;
    private final TextView courseName;
    private final TextView lecturerName;

    private CourseViewHolder(View itemView, CourseAdapter.OnItemClickListener listener, CourseAdapter.OnItemLongClickListener longClickListener) {
        super(itemView);
        courseCode = itemView.findViewById(R.id.textCourseCode);
        courseName = itemView.findViewById(R.id.textCourseName);
        lecturerName = itemView.findViewById(R.id.textLecturerName);



        itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position);
                }

        });


        itemView.setOnLongClickListener(v -> {
            int position = getBindingAdapterPosition();
            if (longClickListener != null && position != RecyclerView.NO_POSITION) {
                longClickListener.onItemLongClick(position);
                return true;
            }
            return false;
        });
    }

    static CourseViewHolder create(ViewGroup parent, CourseAdapter.OnItemClickListener listener, CourseAdapter.OnItemLongClickListener longClickListener) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_course, parent, false);
        return new CourseViewHolder(view, listener, longClickListener);
}

    public void bind(Course course) {
        courseCode.setText(course.getCourseCode());
        courseName.setText(course.getCourseName());
        lecturerName.setText(course.getLecturerName());
    }

    }




