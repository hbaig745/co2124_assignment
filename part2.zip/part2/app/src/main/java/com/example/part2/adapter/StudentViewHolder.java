package com.example.part2.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.R;
import com.example.part2.data.model.Student;

class StudentViewHolder extends RecyclerView.ViewHolder {
    private TextView nameText, emailText, matricText;

    public StudentViewHolder(View itemView) {
        super(itemView);
        nameText = itemView.findViewById(R.id.studentName);
        emailText = itemView.findViewById(R.id.studentEmail);
        matricText = itemView.findViewById(R.id.studentMatric);
    }

    public void bind(Student student) {
        nameText.setText(student.getName());
        emailText.setText(student.getEmail());
        matricText.setText(student.getUserName());
    }
    static StudentViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_course, parent, false);
        return new StudentViewHolder(view);
    }
}