package com.example.part2.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.part2.data.model.Course;
import com.example.part2.data.model.Student;

import java.util.List;

@Dao
public interface CourseDao {

    @Insert
    void insert(Course course);

    @Query("SELECT COUNT(*) FROM courses WHERE courseCode = :courseCode")
    int countCoursesByCourseCode(String courseCode);

    @Query("SELECT * FROM courses")
    LiveData<List<Course>> getAllCourses();

    @Query("SELECT courseId FROM courses WHERE courseCode = :courseCode")
    int getCourseId(String courseCode);

    @Query("DELETE FROM courses WHERE courseId = :courseId")
    void deleteCourse(int courseId);

    @Query("DELETE FROM courses")
    void deleteAll();

    @Query("SELECT * FROM courses WHERE courseId = :courseId")
    LiveData<Course> getCourseById(int courseId);

    @Query("SELECT * FROM courses WHERE courseId IN (SELECT courseId FROM enrollment WHERE studentId = :studentId)")
    LiveData<List<Course>> getCoursesByStudentId(int studentId);

}
