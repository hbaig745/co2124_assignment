package com.example.part2.data.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.part2.data.model.Enrollment;

import java.util.List;

@Dao
public interface EnrollmentDao {

    @Insert
    void enrollStudent(Enrollment enrollment);

    @Delete
    void remove(Enrollment enrollment);

    @Query("SELECT studentId FROM enrollment WHERE courseId = :courseId")
    List<Integer> getStudentsInCourse(int courseId);

    @Query("DELETE FROM enrollment WHERE studentId = :studentId")
    void removeStudentFromAllCourse(int studentId);

    @Query("DELETE FROM enrollment")
    void deleteAll();

    @Query("SELECT COUNT(*) FROM enrollment WHERE studentId = :studentId AND courseId = :courseId")
    int studentInCourse(int studentId, int courseId);

}
