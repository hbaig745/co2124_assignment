package com.example.part2.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.part2.data.model.Student;

import java.util.List;

@Dao
public interface StudentDao {

    @Insert
    void insert(Student student);

    @Query("SELECT * FROM students")
    List<Student> getAllStudents();

    @Query("SELECT studentId FROM students WHERE UserName = :UserName")
    int getStudentId(String UserName);

    @Query("DELETE FROM students WHERE studentId = :studentId")
    void deleteStudent(int studentId);

    @Query("DELETE FROM students")
    void deleteAll();

    @Query("SELECT * FROM students INNER JOIN enrollment ON students.studentId == enrollment.studentId WHERE enrollment.courseId = :courseId")
    LiveData<List<Student>> getStudentsByCourseId(int courseId);
}
