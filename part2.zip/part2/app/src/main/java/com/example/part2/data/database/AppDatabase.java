package com.example.part2.data.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.part2.data.dao.CourseDao;
import com.example.part2.data.dao.StudentDao;
import com.example.part2.data.dao.EnrollmentDao;
import com.example.part2.data.model.Course;
import com.example.part2.data.model.Student;
import com.example.part2.data.model.Enrollment;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Course.class, Student.class, Enrollment.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase INSTANCE;
    private static final int THREADS = 4;
    public static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(THREADS);

    public abstract CourseDao courseDao();
    public abstract StudentDao studentDao();
    public abstract EnrollmentDao enrollmentDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class, "course_management_db"
                    ).build();
                }
            }
        }

        return INSTANCE;
    }


}