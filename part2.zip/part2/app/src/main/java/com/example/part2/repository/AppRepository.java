package com.example.part2.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.part2.data.dao.CourseDao;
import com.example.part2.data.dao.StudentDao;
import com.example.part2.data.dao.EnrollmentDao;
import com.example.part2.data.database.AppDatabase;
import com.example.part2.data.model.Course;
import com.example.part2.data.model.Student;
import com.example.part2.data.model.Enrollment;

import java.util.List;

public class AppRepository {
    private final CourseDao courseDao;
    private final StudentDao studentDao;
    private final EnrollmentDao enrollmentDao;
    private final LiveData<List<Course>> allCourses;

    public AppRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        courseDao = db.courseDao();
        studentDao = db.studentDao();
        enrollmentDao = db.enrollmentDao();

        allCourses = courseDao.getAllCourses();;
    }

    public LiveData<List<Course>> getAllCourses() {
        return allCourses;
    }
    public int countCoursesByCourseCode(String courseCode) {
        return courseDao.countCoursesByCourseCode(courseCode);
    }

    public void insertCourse(Course course) {
        AppDatabase.databaseWriteExecutor.execute(() -> courseDao.insert(course));
    }

    public void insertStudent(Student student) {
        AppDatabase.databaseWriteExecutor.execute(() -> studentDao.insert(student));
    }

    public void enrollStudent(int studentId, int courseId) {
        AppDatabase.databaseWriteExecutor.execute(() -> enrollmentDao.enrollStudent(new Enrollment(studentId, courseId)));
    }

    public void deleteCourse(int courseId) {
        AppDatabase.databaseWriteExecutor.execute(() -> courseDao.deleteCourse(courseId));
    }

    public void deleteStudent(int studentId) {
        AppDatabase.databaseWriteExecutor.execute(() -> studentDao.deleteStudent(studentId));
    }

    public LiveData<Course> getCourseById(int courseId) {
        return courseDao.getCourseById(courseId);
    }

    public LiveData<List<Student>> getStudentsByCourseId(int courseId) {
        return studentDao.getStudentsByCourseId(courseId);
    }
}
