package com.example.part2.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.part2.R;
import com.example.part2.data.model.Course;
import com.example.part2.data.model.Student;
import com.example.part2.viewmodel.AppViewModel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class AddStudentActivity extends AppCompatActivity {

    private EditText editName, editEmail, editUserName;
    private AppViewModel studentViewModel;
    private int courseId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editUserName = findViewById(R.id.editUserName);

        studentViewModel = new ViewModelProvider(this).get(AppViewModel.class);

        courseId = getIntent().getIntExtra("course_id", -1);
    }

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public void addStudent(View view) {
        String name = editName.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String userName = editUserName.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty() || userName.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }



        executorService.execute(() -> {
            boolean studentExists = studentViewModel.doesStudentExist(userName);
            int studentId = studentViewModel.getStudentIdByUserName(userName);
            boolean isEnrolled = studentViewModel.studentInCourse(studentId, courseId);

            runOnUiThread(() -> {
                if (!studentExists) {
                    Student newStudent = new Student(name, userName, email);
                    studentViewModel.insertStudent(newStudent);
                    Toast.makeText(AddStudentActivity.this, "Student Created", Toast.LENGTH_SHORT).show();

                    executorService.execute(() -> {
                        int newStudentId = studentViewModel.getStudentIdByUserName(userName);
                        studentViewModel.enrollStudent(newStudentId, courseId);

                        runOnUiThread(() -> {
                            Toast.makeText(AddStudentActivity.this, "Student Enrolled", Toast.LENGTH_SHORT).show();
                            finish();
                        });
                    });

                } else if (!isEnrolled) {
                    executorService.execute(() -> {
                        studentViewModel.enrollStudent(studentId, courseId);

                        runOnUiThread(() -> {
                                Toast.makeText(AddStudentActivity.this, "Student Enrolled", Toast.LENGTH_SHORT).show();
                                finish();
                        }
                        );
                    });

                } else {
                    Toast.makeText(AddStudentActivity.this, "Student already enrolled", Toast.LENGTH_SHORT).show();
                }
            });
        });

    }
}

