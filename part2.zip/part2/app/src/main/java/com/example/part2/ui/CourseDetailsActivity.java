package com.example.part2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.R;
import com.example.part2.adapter.CourseAdapter;
import com.example.part2.adapter.StudentAdapter;
import com.example.part2.data.model.Student;
import com.example.part2.viewmodel.AppViewModel;

public class CourseDetailsActivity extends AppCompatActivity {
    private TextView courseCodeText, courseNameText, lecturerNameText;
    private RecyclerView studentsRecyclerView;
    private StudentAdapter studentAdapter;
    private AppViewModel courseViewModel;
    private int courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        courseCodeText = findViewById(R.id.courseCodeText);
        courseNameText = findViewById(R.id.courseNameText);
        lecturerNameText = findViewById(R.id.lecturerNameText);
        studentsRecyclerView = findViewById(R.id.studentsRecyclerView);
        studentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        courseId = getIntent().getIntExtra("course_id", -1);

        courseViewModel = new ViewModelProvider(this).get(AppViewModel.class);

        courseViewModel.getCourseById(courseId).observe(this, course -> {
            if (course != null) {
                courseCodeText.setText(course.getCourseCode());
                courseNameText.setText(course.getCourseName());
                lecturerNameText.setText(course.getLecturerName());
            }
        });

        studentAdapter = new StudentAdapter(new StudentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Student student = studentAdapter.getItemAtPosition(position);
                Intent intent = new Intent(CourseDetailsActivity.this, StudentDetailsActivity.class);
                intent.putExtra("student_id", student.getStudentId());
                intent.putExtra("course_id", courseId);
                startActivity(intent);
            }
        });
        studentsRecyclerView.setAdapter(studentAdapter);

        courseViewModel.getStudentsByCourseId(courseId).observe(this, students -> {
            studentAdapter.submitList(students);
        });
    }

    public void navigateToAddStudentActivity(View view) {
        Intent intent = new Intent(this, AddStudentActivity.class);
        intent.putExtra("course_id", courseId);
        startActivity(intent);
    }
}
