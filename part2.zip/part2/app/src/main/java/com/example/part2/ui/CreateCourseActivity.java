package com.example.part2.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.part2.R;
import com.example.part2.data.model.Course;
import com.example.part2.viewmodel.AppViewModel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class CreateCourseActivity extends AppCompatActivity {
    private EditText editCourseCode, editCourseName, editLecturerName;
    private AppViewModel courseViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_course);

        editCourseCode = findViewById(R.id.editCourseCode);
        editCourseName = findViewById(R.id.editCourseName);
        editLecturerName = findViewById(R.id.editLecturerName);

        courseViewModel = new ViewModelProvider(this).get(AppViewModel.class);
    }

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public void createCourse(View view) {
        String courseCode = editCourseCode.getText().toString().trim();
        String courseName = editCourseName.getText().toString().trim();
        String lecturerName = editLecturerName.getText().toString().trim();

        if (courseCode.isEmpty() || courseName.isEmpty() || lecturerName.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        executorService.execute(() -> {
            int count = AppViewModel.countCoursesByCourseCode(courseCode);

            runOnUiThread(() -> {
                if (count > 0) {
                    Toast.makeText(CreateCourseActivity.this, "Course code must be unique", Toast.LENGTH_SHORT).show();
                } else {
                    Course newCourse = new Course(courseCode, courseName, lecturerName);
                    courseViewModel.insertCourse(newCourse);
                    Toast.makeText(CreateCourseActivity.this, "Course Created", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        });
    }
}
