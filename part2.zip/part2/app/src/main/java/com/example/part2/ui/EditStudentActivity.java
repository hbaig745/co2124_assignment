package com.example.part2.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.part2.R;
import com.example.part2.data.model.Student;
import com.example.part2.viewmodel.AppViewModel;

public class EditStudentActivity extends AppCompatActivity {
    private EditText editName, editEmail, editUserName;
    private AppViewModel viewModel;
    private int studentId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);

        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editUserName = findViewById(R.id.editUserName);

        viewModel = new ViewModelProvider(this).get(AppViewModel.class);

        studentId = getIntent().getIntExtra("student_id", -1);

        viewModel.getStudentById(studentId).observe(this, student -> {
            editName.setText(student.getName());
            editEmail.setText(student.getEmail());
            editUserName.setText(student.getUserName());
        });
    }

    public void editStudent(View view) {
        String name = editName.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String userName = editUserName.getText().toString().trim();

        viewModel.getStudentById(studentId).observe(this, student -> {
            student.setName(name);
            student.setEmail(email);
            student.setUserName(userName);
            viewModel.updateStudent(student);
        });
        finish();
    }
}
