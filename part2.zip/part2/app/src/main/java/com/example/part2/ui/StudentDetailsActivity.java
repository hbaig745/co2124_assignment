package com.example.part2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.part2.R;
import com.example.part2.adapter.CourseAdapter;
import com.example.part2.adapter.StudentAdapter;
import com.example.part2.data.model.Enrollment;
import com.example.part2.data.model.Student;
import com.example.part2.viewmodel.AppViewModel;

public class StudentDetailsActivity extends AppCompatActivity {
    private TextView nameText, emailText, userNameText;
    private CourseAdapter courseAdapter;
    private AppViewModel studentViewModel;
    private int studentId;
    private int courseId;
    private RecyclerView courseRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);

        nameText = findViewById(R.id.nameText);
        emailText = findViewById(R.id.emailText);
        userNameText = findViewById(R.id.userNameText);
        courseRecyclerView = findViewById(R.id.courseRecyclerView);
        courseRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        studentId = getIntent().getIntExtra("student_id", -1);
        courseId = getIntent().getIntExtra("course_id", -1);

        studentViewModel = new ViewModelProvider(this).get(AppViewModel.class);

        studentViewModel.getStudentById(studentId).observe(this, student -> {
            if (student != null) {
                nameText.setText(student.getName());
                emailText.setText(student.getEmail());
                userNameText.setText(student.getUserName());
            }
        });

        courseAdapter = new CourseAdapter(new CourseAdapter.CourseDiff(),
                new CourseAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(int position) {
                        Log.d("TAG", "Clicked. Do Nothing");
                    }
                }, new CourseAdapter.OnItemLongClickListener() {
            @Override
            public void onItemLongClick(int position) {
                Log.d("TAG", "Long Clicked. Do Nothing");
            }
        });

        courseRecyclerView.setAdapter(courseAdapter);

        studentViewModel.getCoursesByStudentId(studentId).observe(this, courses -> {
            courseAdapter.submitList(courses);
        });
    }

    public void navigateToEditStudentActivity(View view) {
        Intent intent = new Intent(this, EditStudentActivity.class);
        intent.putExtra("student_id", studentId);
        startActivity(intent);
    }

    public void removeStudent(View view) {
        Enrollment e = new Enrollment(studentId, courseId);
        studentViewModel.removeEnroll(e);
        finish();
    }
}
