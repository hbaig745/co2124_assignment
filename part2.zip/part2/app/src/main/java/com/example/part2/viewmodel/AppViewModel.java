package com.example.part2.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.part2.data.model.Course;
import com.example.part2.data.model.Enrollment;
import com.example.part2.data.model.Student;
import com.example.part2.repository.AppRepository;

import java.util.List;

public class AppViewModel extends AndroidViewModel {

    private static AppRepository repo;
    private final LiveData<List<Course>> allCourses;

    public AppViewModel(Application application) {
        super(application);
        repo = new AppRepository(application);
        allCourses = repo.getAllCourses();
    }

    public static int countCoursesByCourseCode(String courseCode) {
        return repo.countCoursesByCourseCode(courseCode);
    }

    public LiveData<List<Course>> getCoursesByStudentId(int studentId) {
        return repo.getCoursesByStudentId(studentId);
    }

    public boolean doesStudentExist(String userName) {
        return repo.studentExist(userName) == 1;
    }

    public boolean studentInCourse(int studentId, int courseId) {
        return repo.studentInCourse(studentId, courseId) == 1;

    }

    public LiveData<List<Course>> getAllCourses() {
        return allCourses;
    }

    public void insertCourse(Course course) { repo.insertCourse(course); }

    public void insertStudent(Student student) { repo.insertStudent(student); }

    public LiveData<Course> getCourseById(int courseId) {return repo.getCourseById(courseId);}
    public LiveData<Student> getStudentById(int studentId) {return repo.getStudentById(studentId);}

    public LiveData<List<Student>> getStudentsByCourseId(int courseId) { return repo.getStudentsByCourseId(courseId);}

    public void deleteCourse (int courseId) {repo.deleteCourse(courseId);}

    public void enrollStudent(int studentId, int courseId) {repo.enrollStudent(studentId, courseId);}

    public int getStudentIdByUserName(String userName) { return repo.getStudentIdByUserName(userName);}

    public void updateStudent(Student student) {repo.updateStudent(student);};

    public void removeEnroll(Enrollment e) {repo.removeEnroll(e);}
}
