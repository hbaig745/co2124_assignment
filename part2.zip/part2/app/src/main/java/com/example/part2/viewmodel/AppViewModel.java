package com.example.part2.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.part2.data.model.Course;
import com.example.part2.data.model.Student;
import com.example.part2.repository.AppRepository;

import java.util.List;

public class AppViewModel extends AndroidViewModel {

    private static AppRepository repo;
    private final LiveData<List<Course>> allCourses;

    public AppViewModel(Application application) {
        super(application);
        repo = new AppRepository(application);
        allCourses = repo.getAllCourses();
    }

    public static int countCoursesByCourseCode(String courseCode) {
        return repo.countCoursesByCourseCode(courseCode);
    }

    public LiveData<List<Course>> getAllCourses() {
        return allCourses;
    }

    public void insertCourse(Course course) { repo.insertCourse(course); }

    public LiveData<Course> getCourseById(int courseId) {return repo.getCourseById(courseId);}

    public LiveData<List<Student>> getStudentsByCourseId(int courseId) { return repo.getStudentsByCourseId(courseId);}
}
